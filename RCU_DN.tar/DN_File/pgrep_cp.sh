#!/bin/sh
pgrep -l RCU
cp /tftpboot/RCU_App_DN /usr/app/sys
#EOF